import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnN0cmVhbWtpbmdsaXZl')

name = b.b64decode('U3RyZWFta2luZyBMaXZl')

host = b.b64decode('aHR0cDovLzE0NC4yMTcuNzguNzg=')

port = b.b64decode('MjU0NjE=')